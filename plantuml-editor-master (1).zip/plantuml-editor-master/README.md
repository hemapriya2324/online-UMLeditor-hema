# PlantUML Editor

Available on https://pongee.github.io/plantuml-editor/

> React project

## Features

- multiple PlantUML templates
- supports SVG & PNG

## Build Setup

```
# Install dependencies
yarn install

# Build
yarn build-dev

```